import { useState } from "react";
import { 
  FileCheck, Shield, Sparkles, CloudSun, MapPin, Check, X, AlertCircle,
  HelpCircle, Calendar, Coins, ArrowRight, Wallet, RefreshCw, Layers
} from "lucide-react";
import { Claim, ClaimStatus } from "../types";
import MapComponent from "./MapComponent";

interface OfficerDashboardProps {
  userId: string;
  userName: string;
  claims: Claim[];
  onDecideClaim: (
    id: string,
    statusSelected: ClaimStatus,
    comments: string,
    officerWallet: string
  ) => Promise<void>;
  selectedClaimId: string | null;
  setSelectedClaimId: (id: string | null) => void;
  claimDetails: any; // { claim, aiResult, weatherVerification, decisions, appeal }
  loadingDetails: boolean;
  refreshClaims: () => void;
}

export default function OfficerDashboard({
  userId,
  userName,
  claims,
  onDecideClaim,
  selectedClaimId,
  setSelectedClaimId,
  claimDetails,
  loadingDetails,
  refreshClaims,
}: OfficerDashboardProps) {
  const [comments, setComments] = useState("");
  const [isSealing, setIsSealing] = useState(false);
  const [officerWallet, setOfficerWallet] = useState("0x742d35Cc6634C0532925a3b844Bc454e4438f44e");

  // Filter pending or appealed claims for the officer review queue
  const activeQueue = claims.filter((c) => 
    ["pending_officer", "pending_ai", "pending_weather", "appealed"].includes(c.status)
  );

  const handleDecision = async (status: ClaimStatus) => {
    if (!comments.trim()) {
      alert("Please provide official feedback comments justifying this claim status update.");
      return;
    }

    setIsSealing(true);
    try {
      await onDecideClaim(claimDetails.claim.id, status, comments, officerWallet);
      setComments("");
      setSelectedClaimId(null);
      alert(`Claim status updated to ${status.toUpperCase()} and successfully sealed onto Kisan Nyay Ledger!`);
    } catch (err: any) {
      alert("Error submitting decision: " + err.message);
    } finally {
      setIsSealing(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* LEFT COLUMN: Pending/Appealed Review Queue */}
      <div className="lg:col-span-5 space-y-6">
        <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-50 pb-4 mb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-blue-600" />
                Audit Queue
              </h2>
              <p className="text-xs text-slate-500">Inspect farmer-uploaded claims with AI assistance.</p>
            </div>
            <span className="bg-blue-50 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded-full border border-blue-100">
              {activeQueue.length} Active Cases
            </span>
          </div>

          <div className="space-y-3">
            {activeQueue.length === 0 ? (
              <div className="text-center py-16 text-slate-400">
                <Shield className="w-10 h-10 mx-auto mb-2 text-slate-200" />
                <p className="text-xs font-semibold">Verification Queue Empty</p>
                <p className="text-[11px] text-slate-400 mt-1">All registered agricultural claims have been thoroughly evaluated.</p>
              </div>
            ) : (
              activeQueue.map((claim) => {
                const isSelected = selectedClaimId === claim.id;
                
                return (
                  <div
                    key={claim.id}
                    onClick={() => setSelectedClaimId(claim.id)}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? "border-blue-600 bg-blue-50/10 shadow-sm"
                        : "border-slate-100 bg-slate-50/50 hover:bg-slate-50"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <span className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-wider bg-slate-100 px-1.5 py-0.5 rounded">
                          {claim.id}
                        </span>
                        <h4 className="text-sm font-bold text-slate-800 mt-1">{claim.cropType}</h4>
                        <p className="text-[11px] text-slate-500 mt-0.5">Farmer: {claim.farmerName}</p>
                      </div>

                      <span className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full border ${
                        claim.status === "appealed"
                          ? "bg-indigo-50 border-indigo-100 text-indigo-700"
                          : claim.status === "pending_ai"
                          ? "bg-slate-50 border-slate-150 text-slate-500"
                          : "bg-blue-50 border-blue-150 text-blue-700"
                      }`}>
                        {claim.status.replace("_", " ")}
                      </span>
                    </div>

                    <div className="mt-3 grid grid-cols-2 gap-2 text-xs border-t border-slate-100 pt-2 text-slate-500">
                      <div>
                        <span className="text-[9px] text-slate-400 uppercase block">Damage</span>
                        <span className="font-semibold text-slate-700">{claim.damageType}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] text-slate-400 uppercase block">Est. Loss</span>
                        <span className="font-semibold text-blue-600 font-mono">₹{claim.estimatedLossInr.toLocaleString()}</span>
                      </div>
                    </div>

                    <div className="mt-2.5 flex items-center justify-between text-[10px] text-slate-400 pt-1.5">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {new Date(claim.createdAt).toLocaleDateString()}
                      </span>
                      <span className="flex items-center gap-0.5 text-blue-600 font-semibold">
                        Inspect Case <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: Officer Audit Panel */}
      <div className="lg:col-span-7 space-y-6">
        {selectedClaimId && claimDetails ? (
          <>
            {/* Quick overview of claim */}
            <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm">
              <div className="border-b border-slate-100 pb-4 mb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-base font-bold text-slate-900">
                      Audit: {claimDetails.claim.cropType} Loss Case
                    </h2>
                    <p className="text-xs text-slate-500">Filed by {claimDetails.claim.farmerName} on {new Date(claimDetails.claim.createdAt).toLocaleString()}</p>
                  </div>
                  <span className="bg-slate-100 text-slate-600 text-xs font-mono px-2 py-0.5 rounded-md">
                    {claimDetails.claim.id}
                  </span>
                </div>
              </div>

              {/* Loss Details */}
              <div className="grid grid-cols-3 gap-4 text-center mb-6">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Acreage</span>
                  <p className="text-sm font-bold text-slate-800 mt-1">{claimDetails.claim.areaAcres} Acres</p>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Loss Estimated</span>
                  <p className="text-sm font-bold font-mono text-blue-600 mt-1">₹{claimDetails.claim.estimatedLossInr.toLocaleString()}</p>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Reported Damage</span>
                  <p className="text-sm font-bold text-slate-800 mt-1">{claimDetails.claim.damageType}</p>
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] text-slate-400 font-bold uppercase">Farmer Description Statement:</span>
                <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100 leading-relaxed italic">
                  &ldquo;{claimDetails.claim.description}&rdquo;
                </p>
              </div>
            </div>

            {/* AI Results Section */}
            <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  Gemini AI Vision Assessment
                </h3>
                {claimDetails.aiResult ? (
                  <span className="bg-indigo-50 text-indigo-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-indigo-100">
                    Confidence: {Math.round(claimDetails.aiResult.confidenceScore * 100)}%
                  </span>
                ) : (
                  <span className="bg-slate-50 text-slate-400 text-[10px] font-semibold px-2 py-0.5 rounded-full">
                    Awaiting Analysis
                  </span>
                )}
              </div>

              {claimDetails.aiResult ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="border border-slate-100 p-3 rounded-xl bg-slate-50/50">
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Detected Crop</span>
                      <p className="text-xs font-semibold text-slate-700 mt-1">{claimDetails.aiResult.cropTypeDetected}</p>
                    </div>
                    <div className="border border-slate-100 p-3 rounded-xl bg-slate-50/50">
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Severe stress index</span>
                      <p className="text-xs font-semibold text-red-600 mt-1">{claimDetails.aiResult.severity} ({claimDetails.aiResult.severityPercent}%)</p>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase">AI Evidence Reasoning</span>
                    <p className="text-xs text-slate-600 leading-relaxed mt-1 bg-slate-50 p-3 rounded-xl border border-slate-100 font-serif italic">
                      {claimDetails.aiResult.reasoning}
                    </p>
                  </div>

                  {claimDetails.aiResult.manualReviewRequired && (
                    <div className="p-3 bg-amber-50 border border-amber-100 text-amber-800 rounded-xl flex items-start gap-2 text-xs">
                      <AlertCircle className="w-4.5 h-4.5 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold">Manual Flag Triggered:</span> Special inspection advised. Gemini flagged leaf necrosis boundaries or soil abnormalities requiring double-verification.
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-6 text-slate-400 text-xs">
                  AI analysis report has not been triggered yet. Farmers trigger analysis or wait for automatic cron cycle.
                </div>
              )}
            </div>

            {/* Weather Verification Section */}
            {claimDetails.weatherVerification && (
              <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-4">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5 border-b border-slate-100 pb-3">
                  <CloudSun className="w-4.5 h-4.5 text-purple-600" />
                  Meteorological Weather Grid Crosscheck
                </h3>

                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="border border-slate-100 p-2.5 rounded-xl bg-purple-50/10">
                    <span className="text-[9px] text-purple-600 font-bold uppercase block">Anomalous Precip</span>
                    <p className="text-sm font-bold text-purple-900 mt-0.5">{claimDetails.weatherVerification.precipitation} mm</p>
                  </div>
                  <div className="border border-slate-100 p-2.5 rounded-xl bg-purple-50/10">
                    <span className="text-[9px] text-purple-600 font-bold uppercase block">Soil Humidity</span>
                    <p className="text-sm font-bold text-purple-900 mt-0.5">{claimDetails.weatherVerification.humidity}%</p>
                  </div>
                  <div className="border border-slate-100 p-2.5 rounded-xl bg-purple-50/10">
                    <span className="text-[9px] text-purple-600 font-bold uppercase block">Local Temp</span>
                    <p className="text-sm font-bold text-purple-900 mt-0.5">{claimDetails.weatherVerification.temperature}°C</p>
                  </div>
                </div>

                <div className="bg-purple-50/50 border border-purple-100 rounded-xl p-3 text-xs text-purple-800">
                  <p className="font-semibold flex items-center gap-1 mb-1">
                    <FileCheck className="w-4 h-4 text-purple-600" />
                    Station Met Analysis ({claimDetails.weatherVerification.stationName}):
                  </p>
                  <p className="leading-relaxed font-sans">{claimDetails.weatherVerification.analysisNote}</p>
                </div>
              </div>
            )}

            {/* Map geo verification */}
            <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-red-500" />
                Geospatial Mapping Verification
              </h3>
              <div className="h-64 rounded-xl overflow-hidden border border-slate-200">
                <MapComponent
                  latitude={claimDetails.claim.latitude}
                  longitude={claimDetails.claim.longitude}
                  cropType={claimDetails.claim.cropType}
                  damageType={claimDetails.claim.damageType}
                  farmerName={claimDetails.claim.farmerName}
                />
              </div>
            </div>

            {/* Appeal Text details if any */}
            {claimDetails.appeal && (
              <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-6 shadow-sm space-y-3">
                <div className="flex items-center gap-2 border-b border-indigo-150 pb-2">
                  <AlertCircle className="w-4.5 h-4.5 text-indigo-600" />
                  <h4 className="text-sm font-bold text-indigo-950">Active Farmer Grievance / Appeal</h4>
                </div>
                <p className="text-xs text-indigo-800 leading-relaxed">
                  The farmer has filed a dispute following a previous claim decision. Inspect the appeal statement carefully before making your final determination.
                </p>
                <div className="bg-white/80 p-3 rounded-xl border border-indigo-100 text-xs italic text-indigo-900">
                  &ldquo;{claimDetails.appeal.reason}&rdquo;
                </div>
              </div>
            )}

            {/* Officer Audit Form & Sign to Ledger */}
            <div className="bg-white rounded-2xl p-6 shadow-sm space-y-4 border border-slate-200">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="text-sm font-bold flex items-center gap-2 text-slate-900">
                  <Wallet className="w-4 h-4 text-blue-600" />
                  Cryptographic Verification Seal
                </h3>
                <span className="text-[10px] font-mono text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-100 font-semibold">
                  Kisan Nyay Ledger v1.0
                </span>
              </div>

              {/* Wallet configuration */}
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1 flex items-center justify-between">
                  <span>Signer Officer Wallet (Sepolia simulated)</span>
                  <span className="text-[9px] text-blue-600 font-medium">Connected</span>
                </label>
                <input
                  type="text"
                  value={officerWallet}
                  onChange={(e) => setOfficerWallet(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none font-mono focus:ring-2 focus:ring-blue-600"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
                  Audit Findings & Justification (Required)
                </label>
                <textarea
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  rows={3}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none focus:ring-2 focus:ring-blue-600"
                  placeholder="Justify why this claim is approved, rejected, or flagged for more evidence based on Gemini AI vision and meteorological telemetry..."
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <button
                  onClick={() => handleDecision("approved" as ClaimStatus)}
                  disabled={isSealing}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-1 shadow-sm disabled:opacity-50 cursor-pointer"
                >
                  <Check className="w-4 h-4" /> Approve & Mine Block
                </button>
                <button
                  onClick={() => handleDecision("rejected" as ClaimStatus)}
                  disabled={isSealing}
                  className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-1 shadow-sm disabled:opacity-50 cursor-pointer"
                >
                  <X className="w-4 h-4" /> Reject Claim
                </button>
                <button
                  onClick={() => handleDecision("more_evidence" as ClaimStatus)}
                  disabled={isSealing}
                  className="bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 font-bold text-xs py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-1 shadow-sm disabled:opacity-50 cursor-pointer"
                >
                  <AlertCircle className="w-4 h-4 text-amber-700" /> Flag More Evidence
                </button>
              </div>

              <div className="text-[10px] text-slate-400 leading-normal pt-1.5 border-t border-slate-100">
                ⚠️ *Notice:* Approving creates an immutable cryptographic transaction ledger block, recording the claim ID, your wallet address, previous block hash, and a Keccak-256 evidence payload hash.
              </div>
            </div>
          </>
        ) : (
          <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-center bg-white rounded-2xl border border-slate-100 p-12 shadow-sm text-slate-400">
            <Layers className="w-12 h-12 mb-3 text-slate-200 animate-pulse" />
            <h3 className="text-sm font-bold text-slate-800">Select a Claim for Audit</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xs">
              Review claim photo, telemetry sensors, and Gemini reasoning algorithms by clicking on any pending case from the queue.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
